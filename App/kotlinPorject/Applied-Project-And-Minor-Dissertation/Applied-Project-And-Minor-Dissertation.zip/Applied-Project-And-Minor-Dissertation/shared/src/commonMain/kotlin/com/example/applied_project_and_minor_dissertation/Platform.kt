package com.example.applied_project_and_minor_dissertation

expect class Platform() {
    val platform: String
}