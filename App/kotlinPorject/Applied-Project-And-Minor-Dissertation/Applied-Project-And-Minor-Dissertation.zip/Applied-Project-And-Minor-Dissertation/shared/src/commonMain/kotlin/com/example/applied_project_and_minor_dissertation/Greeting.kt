package com.example.applied_project_and_minor_dissertation

class Greeting {
    fun greeting(): String {
        return "Hello, ${Platform().platform}!"
    }
}