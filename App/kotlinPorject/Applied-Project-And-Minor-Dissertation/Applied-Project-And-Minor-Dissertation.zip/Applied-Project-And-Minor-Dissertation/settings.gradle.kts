pluginManagement {
    repositories {
        google()
        gradlePluginPortal()
        mavenCentral()
    }
}

rootProject.name = "Applied-Project-And-Minor-Dissertation"
include(":FitnessBuddy")
include(":shared")